import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';

export default function ParticleBackground() {
  const mountRef = useRef(null);
  // ... (ParticleBackground code as previously defined) ...
  return <div ref={mountRef} style={{position:'fixed',top:0,left:0,width:'100vw',height:'100vh',overflow:'hidden',zIndex:-1}} />;
}
